package org.interview.model;

public class Cardiologist extends Doctor {
    public Cardiologist(String name) {
        super(name);
    }
}
