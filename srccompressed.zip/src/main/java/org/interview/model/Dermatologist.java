package org.interview.model;

public class Dermatologist extends Doctor {
    public Dermatologist(String name) {
        super(name);
    }
}
