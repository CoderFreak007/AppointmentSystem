package org.interview.model;

public class GeneralPhysician extends Doctor {
    public GeneralPhysician(String name) {
        super(name);
    }
}
