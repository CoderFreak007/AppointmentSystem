package org.interview.model;

public class Orthopedic extends Doctor {
    public Orthopedic(String name) {
        super(name);
    }
}
